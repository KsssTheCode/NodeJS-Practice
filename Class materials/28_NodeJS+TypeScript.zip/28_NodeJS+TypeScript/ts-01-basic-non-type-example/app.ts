function add(num1, num2) {
  return num1 + num2;
}

console.log(add(1, 6));

console.log(add('1', '6'));
