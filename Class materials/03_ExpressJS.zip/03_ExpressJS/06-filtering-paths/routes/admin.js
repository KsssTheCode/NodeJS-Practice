const express = require('express');

const router = express.Router();

/* app.get(); / app.post(); ***********************************************************
   - app.use();와 모두 동일하지만, GET(get();), POST(post();)요청에만 반응할 수 있도록하는 메소드 
   - get과 post외에도 delete, patch, put등도 있으나, 일반적인 html문서에서는 사용하기 어려움
   ************************************************************************************/

router.get('/add-product', (req, res, next) => {
  res.send(
    '<form action="/admin/add-product" method="POST"><input type="text" name="title"><button type="submit">Add Product</button></form>'
  );
});

router.post('/add-product', (req, res, next) => {
  console.log(req.body);
  res.redirect('/');
});

module.exports = router;
