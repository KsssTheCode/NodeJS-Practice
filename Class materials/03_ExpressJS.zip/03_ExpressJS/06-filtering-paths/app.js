const path = require('path');

const express = require('express');
// Cmd + 'express'클릭을 하여 백그라운드를 보게되면 e를 내보내고 있음 => 현재 'express' = e 라고 유추할 수 있음

const rootDir = require('../util/path');

const bodyParser = require('body-parser');
// 입력에 대한 분석을 위한 제3자 패키지를 사용하기 위함

const app = express();
// 따라서, express를 함수로 실행하게되면 새로운 객체를 초기 설정하게 되는데,
//       프레임워크(express.js)가 보이지 않는 곳에서 많은 내용을 저장 및 관리하게 됨을 의미

const adminRoutes = require('./routes/admin');
// 코드 이관에 따른 admin.js import구문
const shopRoutes = require('./routes/shop');
// 코드 이관에 따른 shop.js import구문



/* use(); ************************************************************************/
/* express.use(path, (req, res, next) => {}); ************************************
   - 미들웨어 함수를 추가하는 메소드 
   - 모든 http메소드에 반응
   - path : 전달할 경로 (도메인 뒤에 오는 전체 경로가 '/'라는 것이 아닌, '/'로 시작해야한다는 의미)
          : 요청을 여러 Middleware로 routing해주는 역할
   - next : 함수형태로 전달되는 매개변수
     : Express.js를 통해 전달되는 함수
     : 다음함수로 이동할 수 있도록 실행되어야 함 
**********************************************************************************/
/* bodyParser.urlencoded(); *******************************************************
   - 기본적으로 res객체는 들어오는 입력을 분석해주지 않기 때문에 따로 분석하도록 하는 구문(제3자 패키지 'body-parser')
   - 입력에 대한 경로처리 미들웨어 전에 실행해야 함 

   - res.send()와 다르게 전달하는 유형을 자동으로 설정해주지 않지만, form을 통해 전달된 입력은 분석함 
     만약, 다른 유형을 분석하고자하면 적절한 제3자 패키지를 추가로 사용하면 됨
   - 매개변수로 비표준 대상의 분석이 가능한지를 보여주는 extended를 사용함
   - bodyParser.urlencode(); 구문은 자동으로 마지막에 next();를 실행함 
***********************************************************************************/
/* next(); ************************************************************
   - 다음함수로 이동하도록하는 메소드
   - 만약, next();를 호출하지 않아 다음 함수로 넘어가지 않는 경우 요청에 실패하게되므로,
          응답을 보낼 수 있는 곳으로 도달하게 해야함 
***********************************************************************/
// app.use('/', (req, res, next) => {
//     next();
// });
app.use(bodyParser.urlencoded({extended: false}));

// 정적 서비스 방식 - 읽기전용으로 엑세스 허용
app.use(express.static(path.join(__dirname, 'public')));

app.use('/admin', adminRoutes);
// '/admin' 과 같이 url필터링을 했다면, 사용할 때에는 앞에 /admin이 붙어야 404에러가 발생하지 않음

app.use(shopRoutes);
// user용 route를 [route] > shop.js로 이관 후 import

app.use((req, res, next) => {
    /* status() : 요청 상태값을 보낼 수 있는 메소드 **********************************************
       - status, setHeader 등과 메소드 체이닝이 가능하지만, 마지막은 응답을 보내는 send()메소드 이어야 함
    **************************************************************************************/
    //res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
    res.status(404).sendFile(path.join(rootDir, 'views', '404.html'));
});

// const http = require('http');
// const server = http.createServer(app);
// server.listen(3000);
// Cmd + listen클릭을 하여 백그라운드를 보면 express객체에서 listen()이라는 메소드는 위 두 가지 방법을 포함하고 있음
app.listen(3000);

