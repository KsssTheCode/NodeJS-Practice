const express = require('express');

const router = express.Router();

//get();를 사용하여 실행 제한
//만약, use()를 사용하였다면 실행 순서에 각별한 주의가 요구됨 
router.get('/', (req, res, next) => {
  res.send('<h1>Hello from Express!</h1>');
});

module.exports = router;
