const express = require('express');

const router = express.Router();

// 시작경로(path)를 공유하더라도, 메소드가 다르면 반복해서 사용 가능 (메소드가 다르면 route도 다르기때문)
// 만약 router를 호출하는 구문(app.js)에서 겹치는 경로('/admin')를 이미 필터링했다면 겹치는 경로의 파일만 사용 가능 (생략가능)
// ex) [admin.js] router.get('/admin/add-product',~~) -> [app.js] app.use(adminRoutes) (O)
//     [admin.js] router.get('/add-product',~~) -> [app.js] app.use('/admin/adminRoutes) (O)

// /admin/add-product => GET
router.get('/add-product', (req, res, next) => {
  res.send(
    '<form action="/product" method="POST"><input type="text" name="title"><button type="submit">Add Product</button></form>'
  );
});

// /admin/add-product => POST
router.post('/product', (req, res, next) => {
  console.log(req.body);
  res.redirect('/');
});

module.exports = router;
