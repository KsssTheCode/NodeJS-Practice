const fs = require('fs');

const requestHandler = (req, res) => {
  const url = req.url;
  const method = req.method;
  if (url === '/') {
    res.write('<html>');
    res.write('<head><title>Enter Message</title><head>');
    res.write(
      '<body><form action="/message" method="POST"><input type="text" name="message"><button type="submit">Send</button></form></body>'
    );
    res.write('</html>');
    return res.end();
  }
  if (url === '/message' && method === 'POST') {
    const body = [];
    req.on('data', chunk => {
      console.log(chunk);
      body.push(chunk);
    });
    return req.on('end', () => {
      const parsedBody = Buffer.concat(body).toString();
      const message = parsedBody.split('=')[1];
      /* writeFile (경로+파일명, 입력할 값, 오류가발생했을 때의 실행구문) **********/
      fs.writeFile('message.txt', message, err => {
        res.statusCode = 302;
        res.setHeader('Location', '/');
        return res.end();
      });
    });
  }
  res.setHeader('Content-Type', 'text/html');
  res.write('<html>');
  res.write('<head><title>My First Page</title><head>');
  res.write('<body><h1>Hello from my Node.js Server!</h1></body>');
  res.write('</html>');
  res.end();
};

/* 내보내기 방법1 ****************************************************
   키-밸류 형식의 객체를 담을 수도 있음 ( => module.exports = { a : A };)
   NodeJS가 module.exports에 담긴 것이 있는지 확인
   => app.js의 routes객체는 함수가 될 것임 
   ****************************************************************/
//module.exports = requestHandler;

/* 내보내기 방법2 ***************************************************
   여러개의 응답을 하나로 그룹화하여 보낼 때 사용
   => app.js의 routes객체는 객체가 될 것임
      따라서, 사용할 때에는 routes.handler 또는 routes.exText로 사용해야함 
*****************************************************************/
// module.exports = {
//     handler: requestHandler,
//     someText: 'Some hard coded text'
// };

/* 내보내기 방법 3 ********
   - 각각 선언하여 내보내기 
************************/
// module.exports.handler = requestHandler;
// module.exports.someText = 'Some text';
// => NodeJS에 의해 특별히 지정된 단축키로 module.은 생략해도 가능함
exports.handler = requestHandler;
exports.someText = 'Some hard coded text';