const http = require('http');
const fs = require('fs');

/*  createServer(req, res);  *************************
   - 서버를 실행하도록 하는 메소드
   - createServer메소드에 필요한 request와 response를 생성 
******************************************************/
const server = http.createServer((req, res) => {
  const url = req.url;
  const method = req.method;
  if (url === '/') {
    res.write('<html>');
    res.write('<head><title>Enter Message</title><head>');
    res.write('<body><form action="/message" method="POST"><input type="text" name="message"><button type="submit">Send</button></form></body>');
    res.write('</html>');
    return res.end();
  }
  if (url === '/message' && method === 'POST') {
    const body = [];
    req.on('data', (chunk) => {
      console.log(chunk);
      body.push(chunk);
    });
    req.on('end', () => {
      const parsedBody = Buffer.concat(body).toString();
      const message = parsedBody.split('=')[1];
      /* writeFileSync (경로+파일명, 입력할 값) ******************************************
          - 해당 경로에 해당 이름의 파일을 생성하고, 입력할 값을 적어주는 메소드
          - Sync(Synchronous)(동기화) : 파일이 생성되기 전까지 코드 실행을 막는 메소드
                                     : sync구문이 완료될 때까지 다른 요청들이 받아들여지지 않으므로
                                       Node.js에서는 사용하지 않는 것을 권장                
      *******************************************************************************/
      fs.writeFileSync('message.txt', message);
    });

    /*  statusCode(상태코드) : 다음 경로를 재지정 ******************/
    //res.statusCode = 302;

    /*  Location ******************************************************
        - 브라우저에서 제공하는 Default Header
        - ' / '로 설정하게되면 실행되고있는 Host(localhost)를 자동으로 사용하게 됨 
    *******************************************************************/
    //res.setHeader('Location', '/');

    // 위 두 코드를 한 줄로도 표현가능
    res.writeHead(302, { 'Location' : '/'});

    return res.end();
  }

  /*  res.setHeader('Content-Type', 'application/json'); ****
     - Content-type과 전달할 객체타입를 설정하는 메소드              
  ***********************************************************/
  res.setHeader('Content-Type', 'text/html');

  res.write('<html>');
  res.write('<head><title>My First Page</title><head>');
  res.write('<body><h1>Hello from my Node.js Server!</h1></body>');
  res.write('</html>');
  res.end();
});

/*  listen(port No);  ***********************************************************
    - 코드가 종료되더라도 node server가 종료되지않고 무한으로 대기할 수 있도록 하기 위함
    - listen메소드가 잘 작동하고 있다면, 터미널에 해당 파일 실행 시 종료되지 않고 커서가 계속 깜빡임
*********************************************************************************/
server.listen(3000);
